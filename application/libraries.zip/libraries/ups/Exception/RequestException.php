<?php

namespace Ups\Exception;

use Exception;

class RequestException extends Exception
{
}
