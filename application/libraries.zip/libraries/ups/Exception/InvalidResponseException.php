<?php

namespace Ups\Exception;

use Exception;

class InvalidResponseException extends Exception
{
}
